package com.example.met_qua;

public record FrameData(int dataType, byte[] data) {
}
